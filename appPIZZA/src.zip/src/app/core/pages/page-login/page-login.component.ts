import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pizza-page-login',
  templateUrl: './page-login.component.html',
  styleUrls: ['./page-login.component.css']
})
export class PageLoginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
