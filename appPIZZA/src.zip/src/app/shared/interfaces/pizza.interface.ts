export interface MetaDataColumn {
    name: string;
    ingredients: string;
    price: number
}